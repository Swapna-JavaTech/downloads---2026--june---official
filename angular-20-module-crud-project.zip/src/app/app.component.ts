import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<h1>Angular 20 CRUD App</h1><app-product-list></app-product-list>`
})
export class AppComponent { }
