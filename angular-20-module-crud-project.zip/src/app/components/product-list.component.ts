import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { Product } from '../models/product.model';

@Component({
  selector: 'app-product-list',
  template: `
    <h2>Product List</h2>

    <form (ngSubmit)="addProduct()">
      <input [(ngModel)]="newProduct.name" name="name" placeholder="Name" required />
      <input [(ngModel)]="newProduct.price" name="price" placeholder="Price" type="number" required />
      <button type="submit">Add</button>
    </form>

    <ul>
      <li *ngFor="let product of products">
        {{product.name}} - ₹{{product.price}}
        <button (click)="deleteProduct(product.id!)">Delete</button>
      </li>
    </ul>
  `
})
export class ProductListComponent implements OnInit {

  products: Product[] = [];
  newProduct: Product = { name: '', price: 0 };

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.loadProducts();
  }

  loadProducts() {
    this.productService.getProducts().subscribe(data => this.products = data);
  }

  addProduct() {
    this.productService.addProduct(this.newProduct).subscribe(() => {
      this.newProduct = { name: '', price: 0 };
      this.loadProducts();
    });
  }

  deleteProduct(id: number) {
    this.productService.deleteProduct(id).subscribe(() => {
      this.loadProducts();
    });
  }
}
