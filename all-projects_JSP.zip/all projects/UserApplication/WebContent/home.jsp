<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Welcome</title>
</head>
<body>
<h1>Fill the form given below:</h1>
<form method="post" action="success.jsp">
User : <input type="text" name="userName"><br>
Email: <input type="email" name="emailID">
<input type="submit" value="submit">
</form>

</body>
</html>