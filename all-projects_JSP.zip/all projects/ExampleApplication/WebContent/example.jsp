<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Scriptlet Tag Example</title>
</head>
<h1>Example to print k iterations</h1>
<%!
       int k;
   %>
  <body>
  <%
         for(k=1;k<=10;++k) {
           out.println(k);
         }
%>
<br>
<%
  out.println("The value of --k is:");
  %>
  <%= --k %>
  <br>
 Updated on: <%= (new java.util.Date()).toLocaleString() %>
</body>
</html>